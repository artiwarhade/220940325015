import java.util.*;
class Employee{
	String name;
	int salary;
	String date;
	public Employee(String name,int salary,String date){
		this.name=name;
		this.salary=salary;
		this.date=date;
	}
	public static void main(String arg[]){
	Employee[] emp=new Employee[10];
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter number of Employee");
	int empNum=sc.nextInt();
	for(int i=0;i<empNum;i++){
		System.out.println("Enter the name of Employee " +(i+1)+" : ");
		String name=sc.next();
		System.out.println("Enter the salary of Employee "+(i+1)+" :");
		int salary=sc.nextInt();
		System.out.println("Enter the date of joining of Employee "+(i+1)+" :");
		String date=sc.next();
		emp[i]=new Employee(name,salary,date);
	}
	for(int j=0;j<empNum;j++){
	System.out.println("\nEmployee "+(j+1)+" : ");
	System.out.println("\nName : "+emp[j].name+" Salary : "+emp[j].salary+" Date of Joining : "+emp[j].date);
	}

	}	
}