import java.util.Scanner;
class BankAccount{
String name;
String address;
int balance;
int numOfTransaction=0;
static int generator=999;
int accountNum;
String accountType;

	BankAccount(String name,String address,int balance,String Type){
		generator+=1;
	this.accountNum=generator;
	this.name=name;
	this.address=address;
	this.balance=balance;
	this.numOfTransaction+=1;
	this.accountType=Type;
	System.out.println("Congratulations your account is successfully created:\nAccount Number : "+accountNum+"\nName : "+name);
	}

	void balanceInfo(){
		System.out.println("Account number"+accountNum+"\nName : "+name+"\nBalance : "+balance);
	}

	void deposit(int amount){
	balance+=amount;
	System.out.print("Your current balance is : "+balance);
	}

	void withdraw(int amount){
		if (balance>=amount){
		balance-=amount;
		System.out.println("Successfully withdrawn : "+amount);
		System.out.print("Your current balance is : "+balance);
		}
		else{
		System.out.println("Insufficient amount");
		}
	}

	void addressChange(String add){
	address=add;
	}


	}



class Bank{
	public static void main(String args[]){
	Scanner sc=new Scanner(System.in);
	BankAccount[] depositor=new BankAccount[10];
	while(true){
	System.out.println("Choose an option you want to perform \n1.To create account\n2.To deposit amount\n3.To withdraw amount\n4.To show balance\n5.To change address\n6.To stop program enter 100");
	int a=sc.nextInt();
	if (a==100){
		break;
	}
	else{
	switch(a){

	case 1:
			System.out.println("Enter number of depositor");
			int depnum=sc.nextInt();
 			for(int i=0;i<depnum;i++){
 				System.out.println("Enter the name of account holder");
 				String name=sc.next();
 				System.out.println("Enter your address");
 				String address=sc.next();
 				System.out.println("Enter the amount to deposit for 1 transation : ");
 				int amount=sc.nextInt();
 				System.out.println("Select type of account : Savings or Current" );
 				String type=sc.next();
 				depositor[i]=new BankAccount(name,address,amount,type);	
 			}
 			break;


 	case 2:
			System.out.println("Enter the account number : ");
 			int accountnumb=sc.nextInt(); 		
 			int flag=1;
 			for(int i=0;i<depositor.length;i++){
 			if(depositor[i].accountNum==accountnumb){
 				System.out.println("Enter the amount to deposit : ");
 				int amount=sc.nextInt();
 				depositor[i].deposit(amount);
 				flag=0;
 			}
 			}
 			if (flag!=0){
 			System.out.println("Invalid account number");
 			}
 			break;
 	case 3:
  			System.out.println("Enter the account number : ");
 			int accountnumb2=sc.nextInt();
 			int flag2=1;
 			for(int i=0;i<depositor.length;i++){
 			if(depositor[i].accountNum==accountnumb2){
 				System.out.println("Enter the amount to withdraw : ");
 				int amount=sc.nextInt();
 				depositor[i].withdraw(amount);
 				flag2=0;
 			}
 			}
 			if (flag2!=0){
 			System.out.println("Invalid account number");
 			}
 			break;

 	case 4:
  			System.out.println("Enter the account number : ");
 			int accountnumb3=sc.nextInt();
 			int flag3=1;
 			for(int i=0;i<depositor.length;i++){
 			if(depositor[i].accountNum==accountnumb3){
 				depositor[i].balanceInfo();
 				flag3=0;
 			}
 			}
 			if (flag3!=0){
 			System.out.println("Invalid account number");
 			}
 	case 5:
  			System.out.println("Enter the account number : ");
 			int accountnumb4=sc.nextInt();
 			int flag4=1;
 			for(int i=0;i<depositor.length;i++){
 			if(depositor[i].accountNum==accountnumb4){
 				System.out.println("Enter your address");
 				String address=sc.next();
 				depositor[i].addressChange(address);
 				flag4=0;
 			}
 			}
 			if (flag4!=0){
 			System.out.println("Invalid account number");
 			}
 			break;

		}
	}
}


	}
}