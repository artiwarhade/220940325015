import java.util.Scanner;
 class Student{
	int rollNo=100;
	int mathMarks;
	int chemMarks;
	int physMarks;
	Student(int mMarks,int cMarks,int pMarks){
	rollNo=rollNo+1;
	this.rollNo=rollNo;
	this.mathMarks=mMarks;
	this.chemMarks=cMarks;
	this.physMarks=pMarks;
	}
	double avg(){
	double avg=(mathMarks+chemMarks+physMarks)/3;
	return avg;
	}
}
 class StudentInfo{

public static void main(String arg[]){
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter number of Student");
	int stuNum=sc.nextInt();
	Student[] student=new Student[stuNum];

	for(int i=0;i<stuNum;i++){
	System.out.println("Details of Student "+(i+1)+" : ");
	System.out.println("Enter marks of math :");
	int math=sc.nextInt();
	System.out.println("Enter marks of chemistry :");
	int chem=sc.nextInt();
	System.out.println("Enter marks of Physics :");
	int phys=sc.nextInt();
	student[i]=new Student(math,chem,phys);
	}

	for(int i=0;i<stuNum;i++){
	System.out.println("\nStudent "+(i+1)+" information :");
	System.out.println("Roll Number : "+student[i].rollNo+" Maths marks : "+student[i].mathMarks+" Chemistry marks: "+student[i].chemMarks+" Physics marks : "+student[i].physMarks);
	System.out.println("Average marks : "+student[i].avg());
	}

	}
}